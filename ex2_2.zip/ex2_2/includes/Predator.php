<?php
namespace includes;

abstract class Predator extends Animal{
    
    
    public function Roar()
    {
        echo "wrrrrr";
    }

    

  
}
