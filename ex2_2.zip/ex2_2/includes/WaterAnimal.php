<?php
namespace includes;

abstract class WaterAnimal extends Animal{
    
      public function Swim()
      {
        echo "splah";
      }
}