<?php
namespace includes;

abstract class Flying extends Animal
{
    public function Fly()
    {
        echo "whoohooo";
    }
}