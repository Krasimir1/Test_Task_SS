<?php
namespace includes;

class Dolphin extends WaterAnimal
{
    
    function __construct() 
    {
//        echo "I am a dolphin!";
    }
    
    
    
}
