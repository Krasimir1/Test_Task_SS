<?php
namespace includes;

abstract class Animal implements IAnimal 
{

    private $Age;
    private $Name;
    private $Sex;
    private $ImageURL;
    private $DOB;
    public function Sleep() 
    {
        echo "zzzzzz";
    }

    public function getAge() 
    {
        return $this->Age;
    }

    public function setAge($age) 
    {
        $this->Age = $age;
    }

    public function getName() 
    {
        return $this->Name;
    }

    public function setName($name) 
    {
        $this->Name = $name;
    }

    public function getSex() 
    {
        return $this->Sex;
    }

    public function setSex($sex) 
    {
        $this->Sex = $sex;
    }
    
    public function getImageURL()
    {
        return $this->ImageURL;
    }
    
    public function setImageURL($url)
    {
        $this->ImageURL = $url;
    }
    
    public function getDOB()
    {
        return $this->DOB;
    }
    
    public function setDOB($dob)
    {
        $this->DOB = $dob;
    }

}

