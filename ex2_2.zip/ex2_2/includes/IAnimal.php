<?php
namespace includes;

interface IAnimal 
{

    public function Sleep();

    public function getAge();

    public function setAge($age);

    public function getName();

    public function setName($name);

    public function getSex();

    public function setSex($sex);

    public function getImageURL();

    public function setImageURL($url);

    public function getDOB();

    public function setDOB($dob);
}

