<?php
namespace includes;
trait Eating{
    public function Eat(){
            echo "yummy";
    }
}