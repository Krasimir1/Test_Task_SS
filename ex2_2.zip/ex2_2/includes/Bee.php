<?php
namespace includes;
require_once 'Flying.php';

class Bee extends Flying 
{
       function __construct() 
       {
            //echo "I am a bee!";
        }
}