<?php
require "../vendor/autoload.php";

ini_set("allow_url_fopen", 1);
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: OPTIONS,GET,POST,PUT,DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
$json = file_get_contents('php://input');

$data = json_decode($json, true);

$animalsArray = array();
//преминава се през всички елементи като зависимост от полето species се създава обект от нужния клас и се пълни масив с обекти
foreach ($data as $element) {

    switch ($element['species']) {
        case "Lion":
            $lion = new includes\Lion;
            $lion->setName($element['name']);
            $lion->setImageURL($element['image']);
            $lion->setSex($element['sex']);
            $lion->setDOB($element['DOB']);
            $animalsArray[] = $lion;
            break;
        case "Eagle":
            $eagle = new includes\Eagle;
            $eagle->setName($element['name']);
            $eagle->setImageURL($element['image']);
            $eagle->setSex($element['sex']);
            $eagle->setDOB($element['DOB']);
            $animalsArray[] = $eagle;
            break;
        case "Bee":
            $bee = new includes\Bee;
            $bee->setName($element['name']);
            $bee->setImageURL($element['image']);
            $bee->setSex($element['sex']);
            $bee->setDOB($element['DOB']);
            $animalsArray[] = $bee;
            break;
        case "Dolphin":
            $dolphin = new includes\Dolphin;
            $dolphin->setName($element['name']);
            $dolphin->setImageURL($element['image']);
            $dolphin->setSex($element['sex']);
            $dolphin->setDOB($element['DOB']);
            $animalsArray[] = $dolphin;
            break;
    }
}
?>

<div class="container">
    <?php
    //цикъл за визуализиране на обектите 
    foreach ($animalsArray as $animal) {
        $methods = get_class_methods($animal);
        ?>
        <div class="animal-container"> 
            <div>
                <img src='<?= $animal->getImageURL() ?>'/>
            </div>
            <div>
                This is <?php echo $animal->getName() . " "; ?> it can
                <?php
                foreach ($methods as $method) {
                    if ($method == "Sleep" || $method == "Fly" || $method == "Eat" || $method == "Roar") {
                        echo $animal->$method() . " - " . $method . ",  ";
                    }
                }
                ?>
            </div>
        </div>
        <?php
    }
    ?>

</div>
