
<html>
    <head>
        <link rel="stylesheet" href="../css/main.css">
    </head>
    <body>
        <?php
        if (isset($_POST['submit'])) {
            $url = 'http://localhost/ex2_2/api/ex2.php';
            $data = '[
	{
		"name": "Simba",
		"species": "Lion",
		"sex": "male",
		"DOB": "2019-02-02",
		"image": "https://images-na.ssl-images-amazon.com/images/I/41NbQKPYPrL._SX355_.jpg"
	},
	{
		"name": "Momfasa",
		"species": "Lion",
		"sex": "male",
		"DOB": "2010-12-22",
		"image": "https://pbs.twimg.com/profile_images/894868864940617728/p0fnYoWg_400x400.jpg"
	},
	{
		"name": "Boris",
		"species": "Lion",
		"sex": "male",
		"DOB": "2007-09-02",
		"image": "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9e/Lion_%28Panthera_leo%29_male_6y.jpg/200px-Lion_%28Panthera_leo%29_male_6y.jpg"
	},
	{
		"name": "Dodo",
		"species": "Dolphin",
		"sex": "male",
		"DOB": "2004-04-12",
		"image": "https://i.ndtvimg.com/i/2017-02/dolphin-620x350_620x350_71488270579.jpg"
	},
	{
		"name": "Ronda",
		"species": "Eagle",
		"sex": "female",
		"DOB": "2017-02-25",
		"image": "https://i.pinimg.com/originals/32/46/8c/32468cd612605d07175f57e065292d5a.jpg"
	},
	{
		"name": "Maya",
		"species": "Bee",
		"sex": "female",
		"DOB": "2020-04-21",
		"image": "https://i.pinimg.com/originals/8a/c5/8a/8ac58a9e0f59ef460127212e6ef93fe3.png"
	}

]';


            $options = array(
                'http' => array(
                    'method' => 'POST',
                    'content' => $data,
                    'header' => "Content-Type: application/json\r\n" .
                    "Accept: application/json\r\n"
                )
            );

            $context = stream_context_create($options);
            $result = file_get_contents($url, false, $context);

            echo $result;
            $response = json_decode($result);
        } else {
            ?>
            <div class="container">
                <form method="post" action="">
                    <input class="button" type="submit" value="Request" name="submit"/>
                </form>
            </div>
            <?php
        }
        ?>
    </body>
</html>