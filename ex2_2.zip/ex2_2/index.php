<?php
require "vendor/autoload.php";


$dolphin = new includes\Dolphin;
$dolphin->setAge(10);
echo "<br>";
$dolphin->Sleep();
echo "<br>";
$dolphin->Swim();
echo "<br>";
echo "<br>";

$lion = new includes\Lion;
$lion->setAge(20);
echo "<br>";
$lion->Sleep();
echo "<br>";
$lion->Roar();
echo "<br>";
$lion->Eat();
echo "<br>";
echo "<br>";

$eagle = new includes\Eagle;
$eagle->setAge(50);
echo "<br>";
$eagle->Sleep();
echo "<br>";
$eagle->Fly();
echo "<br>";
$eagle->Eat();
echo "<br>";
echo "<br>";

$bee = new includes\Bee();
$bee->setAge(1);
echo "<br>";
$bee->Sleep();
echo "<br>";
$bee->Fly();
echo "<br>";
echo "<br>";






