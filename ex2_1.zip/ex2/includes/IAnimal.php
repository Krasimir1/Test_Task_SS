<?php
namespace includes;

interface IAnimal 
{

    public function Sleep();

    public function getAge();

    public function setAge($age);

}

