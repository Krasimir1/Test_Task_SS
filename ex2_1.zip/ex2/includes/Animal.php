<?php
namespace includes;

abstract class Animal implements IAnimal 
{

    private $Age;

    public function Sleep() 
    {
        echo "zzzzzz";
    }

    public function getAge() 
    {
        return $this->Age;
    }

    public function setAge($age) 
    {
        $this->Age = $age;
    }

}

