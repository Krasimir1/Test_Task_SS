<?php
namespace includes;
require_once "traits/Eating.php";

class Eagle extends Flying 
{
       function __construct() 
       {
           echo "I am an eagle!";
       }
    use Eating;
    
}