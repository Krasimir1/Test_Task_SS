<?php
 namespace includes;
 require_once "traits/Eating.php";
class Lion extends Predator
{
   
    function __construct() 
    {
       echo "I am a lion!";
    
    }
    use Eating;
}
